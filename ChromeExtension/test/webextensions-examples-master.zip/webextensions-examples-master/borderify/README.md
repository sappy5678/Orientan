# borderify

## What it does

This extension just includes:

* a content script, "borderify.js", that is injected into any pages
under "mozilla.org/" or any of its subdomains

The content script draws a border around the document.body.

## What it shows

* how to inject content scripts declaratively using manifest.json

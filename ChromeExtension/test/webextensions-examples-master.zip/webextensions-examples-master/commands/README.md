# commands

This extension includes:

* a background script, "background.js"

All it does is:

* register a shortcut (Ctrl+Shift+U) to send a command to the extension (Command+Shift+U on a Mac).",

It shows:

* how to use chrome.commands to register keyboard shortcuts for your extension.

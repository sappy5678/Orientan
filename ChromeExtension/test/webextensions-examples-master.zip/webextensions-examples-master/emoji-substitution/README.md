# Emoji Substitution

## What it does

Replaces words that describe an emoji with the emoji itself.

## What it shows

A good example for beginners that can be used as a "make your first add-on" tutorial and / or referenced to create other add-ons.
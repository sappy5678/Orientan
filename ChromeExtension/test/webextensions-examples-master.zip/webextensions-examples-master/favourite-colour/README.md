# Favourite Colour

Shows and stores your favourite colour, in storage.local
in the about:addons page for the add-on.

Demonstrates: storing data with storage.local, runtime.openOptionsPage and
creating an options page.
